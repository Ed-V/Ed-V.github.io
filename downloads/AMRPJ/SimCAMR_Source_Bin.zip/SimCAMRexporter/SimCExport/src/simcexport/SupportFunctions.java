/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package simcexport;

/**
 *
 * @author ED
 */
import java.io.*;
import java.util.Scanner;

public class SupportFunctions {

    //private String fileName = "";
    //private String outputFile = "";
    private FileInputStream fileInput;
    private String[] stats = new String[9];
    private double[] statNum = new double[9];
    private int counter = 0;


    public SupportFunctions() {

    }

    public void run() throws IOException {

        generateExport();

    }

    public void generateExport() throws IOException {
        Scanner fileReader = new Scanner(fileInput);
        String stream = "";
        int tempcounter = 0;
        //set the string data
        while ((fileReader.hasNextLine()) && (stream.equals("<th class=\"left\">Scale Factors</th>") == false)) {
            stream = fileReader.nextLine();
           // System.out.print("\nCounter before: " + counter);
            setDataStrings(stream);
            //System.out.print("\nCounter after: " + counter);
            //System.out.print("\n" + stream);
        }

        //set the numbers
        while (tempcounter < counter) {
            stream = fileReader.nextLine();
            setDataNum(stream, tempcounter);
            tempcounter++;
        }

    }

    public void openFile(String file) throws IOException {
        fileInput = new FileInputStream(file);

    }

    public void closeFile() throws IOException {
        //Thank god for short circuiting
        if (fileInput != null && fileInput.available() != 0) {
            fileInput.close();
            //System.out.print("\nClosed file!");
        }
    }

    public void saveFile(String outFile) throws IOException{
        FileOutputStream fout = new FileOutputStream(outFile);
        OutputStreamWriter outWriter= new OutputStreamWriter(fout);
        
        int tempCounter=0;
        
        while(tempCounter<counter)
        {
            outWriter.write(stats[tempCounter]+statNum[tempCounter]+System.getProperty("line.separator"));
            tempCounter++;
        }
        
        outWriter.close();
        fout.close();
    }
    
    private void setDataStrings(String data) {
        switch (data) {
            case "<th>Wdps</th>":
                stats[counter] = "MainHandDps               ";
                counter++;
                break;
            case "<th>WOHdps</th>":
                stats[counter] = "OffHandDps                ";
                counter++;
                break;
            case "<th>AP</th>":
                stats[counter] = "AttackPower               ";
                counter++;
                break;
            case "<th>Agi</th>":
                stats[counter] = "Agility                   ";
                counter++;
                break;
            case "<th>Crit</th>":
                stats[counter] = "CriticalStrike            ";
                counter++;
                break;
            case "<th>Mastery</th>":
                stats[counter] = "Mastery                   ";
                counter++;
                break;
            case "<th>Haste</th>":
                stats[counter] = "Haste                     ";
                counter++;
                break;
            case "<th>Mult</th>":
                stats[counter] = "Multistrike               ";
                counter++;
                break;
            case "<th>Vers</th>":
                stats[counter] = "Versatility               ";
                counter++;
                break;

        }
    }

    private void setDataNum(String num, int counter) {
        String temp = num.substring(4, 8);
        statNum[counter]=Double.parseDouble(temp);
        //System.out.print("\n" + temp);

    }

}
