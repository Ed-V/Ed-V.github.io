/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package simcexport;

import java.util.*;
import java.io.*;

public class SimCExport {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        MainWindow window = new MainWindow();
        window.setLocationRelativeTo(null);
        window.setVisible(true);
    }
//
//        String fileName = "";
//        String outputName = "";
//        Scanner input = new Scanner(System.in);
//
////Prompt the user to enter file name
//        System.out.print("Enter file name: ");
//        fileName = input.next();
//        System.out.print("Enter name to save as: ");
//        outputName = input.next();
//        SupportFunctions amrExport = new SupportFunctions(fileName, outputName);
//
//        //Generate the flie to save
//        try {
//            amrExport.run();
//        } catch (IOException ioe) {
//            System.out.print("\nFailed to find file");
//            System.exit(1);
//            
//        }
//        System.out.print("\nFile was sucessfully saved!\nEnd of program");

}
